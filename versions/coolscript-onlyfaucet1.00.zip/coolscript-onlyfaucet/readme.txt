Admin Panel information:
Username: Admin
Password: 123456

cronjob:
https://yourdomain.com/includes/cronjob.php
only 1 times/ 24 hour
The cronjob deletes entries older than 48 hours.